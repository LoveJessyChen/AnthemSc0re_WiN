1. Install Anthemscore
2. Run it (don't update) and close
3. Turn off the internet
4. Copy license license_v2.dat to C:\Users\your_name\AppData\Local\AnthemScore
5. Run keygen, push "SAVE" button
6. Turn on the internet

Don't forget to turn off updates: FILE -> preferences -> "check for updates on startup"